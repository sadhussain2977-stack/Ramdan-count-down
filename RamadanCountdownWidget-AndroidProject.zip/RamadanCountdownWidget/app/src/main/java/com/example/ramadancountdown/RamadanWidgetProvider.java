package com.example.ramadancountdown;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.widget.RemoteViews;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class RamadanWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_TICK = "com.example.ramadancountdown.TICK";
    // Midnight at the start of the expected first day, Pakistan Standard Time.
    private static final long TARGET = 1802026800000L; // 2027-02-08 00:00:00 +05:00

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
        schedule(context);
    }

    @Override public void onEnabled(Context context) { schedule(context); }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_TICK.equals(intent.getAction())) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName component = new ComponentName(context, RamadanWidgetProvider.class);
            int[] ids = manager.getAppWidgetIds(component);
            for (int id : ids) updateOne(context, manager, id);
            schedule(context);
        }
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, RamadanWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
        schedule(context);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        long remaining = Math.max(0L, TARGET - System.currentTimeMillis());
        long days = TimeUnit.MILLISECONDS.toDays(remaining);
        long hours = TimeUnit.MILLISECONDS.toHours(remaining) % 24;
        long minutes = TimeUnit.MILLISECONDS.toMinutes(remaining) % 60;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(remaining) % 60;

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.ramadan_widget);
        views.setTextViewText(R.id.days, String.valueOf(days));
        views.setTextViewText(R.id.hours, String.format(Locale.US, "%02d", hours));
        views.setTextViewText(R.id.minutes, String.format(Locale.US, "%02d", minutes));
        views.setTextViewText(R.id.seconds, String.format(Locale.US, "%02d", seconds));
        views.setTextViewText(R.id.status, remaining == 0
                ? "Ramadan may have begun — confirm moon sighting"
                : "Expected 8 February 2027 • Pakistan");
        manager.updateAppWidget(id, views);
    }

    private static void schedule(Context context) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, RamadanWidgetProvider.class).setAction(ACTION_TICK);
        PendingIntent pending = PendingIntent.getBroadcast(context, 1448, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        alarms.cancel(pending);
        alarms.setInexactRepeating(AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + 1000, 60_000, pending);
    }
}
