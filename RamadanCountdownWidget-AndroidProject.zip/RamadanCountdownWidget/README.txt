RAMADAN COUNTDOWN 1448 AH — ANDROID HOME-SCREEN WIDGET

This is a native Android Studio project. It runs fully offline and uses Pakistan Standard Time.
Expected target: 8 February 2027, 00:00 PKT. The official start depends on moon sighting.

BUILD:
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync and install any requested Android SDK platform (API 35).
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android phone.
5. Long-press an empty area of the home screen > Widgets > Ramadan Countdown.
6. Drag the widget onto the home screen.

NOTES:
- Android launchers and battery-saving settings may delay widget refreshes; the widget requests a periodic refresh about once per minute, but Android may batch background alarms.
- The countdown is approximate until Pakistan's official moon-sighting announcement.
- No internet permission or network access is included.
